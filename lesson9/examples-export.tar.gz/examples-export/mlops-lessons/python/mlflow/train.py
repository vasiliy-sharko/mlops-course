from ftplib import MAXLINE
import mlflow
import mlflow.sklearn
from sklearn.datasets import load_iris
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, log_loss
import os
from pathlib import Path

from mlflow.tracking import MlflowClient

client = MlflowClient()


def push_to_prometheus(accuracy, loss, job_name="mlflow_training"):
    """
    Простая функция для отправки метрик в Prometheus Pushgateway
    """
    try:
        from prometheus_client import CollectorRegistry, Gauge, push_to_gateway
        
        # URL Pushgateway (можно задать через переменную окружения)
        gateway_url = os.environ.get('PUSHGATEWAY_URL', 'localhost:9091')
        
        # Создаем реестр метрик
        registry = CollectorRegistry()
        
        # Создаем метрики
        accuracy_gauge = Gauge('mlflow_accuracy', 'Model accuracy', registry=registry)
        loss_gauge = Gauge('mlflow_loss', 'Model loss', registry=registry)
        
        # Устанавливаем значения
        accuracy_gauge.set(accuracy)
        loss_gauge.set(loss)
        
        # Отправляем в Pushgateway
        push_to_gateway(gateway_url, job=job_name, registry=registry)
        print(f"📊 Метрики отправлены в Pushgateway: {gateway_url}")
        
    except ImportError:
        print("⚠️ prometheus_client не установлен. Для установки: pip install prometheus_client")
    except Exception as e:
        print(f"⚠️ Не удалось отправить метрики в Pushgateway: {e}")
        print("💡 Проверьте доступность Pushgateway и настройки сети")


# Параметри, які хочемо варіювати
learning_rate = 0.01
epochs = 100
model_name = "mlops_classifier_model"
model_version = "0.0.2"
mlflow_model_version = "100"
# Старт логування
mlflow.set_experiment("MLOps Classification Demo Project v1.0.0")

# Створення унікального імені для запуску
import datetime
timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
run_name = f"iris_lr_{learning_rate}_epochs_{epochs}_{timestamp}"

print(f"🚀 Запускаю тренування: {run_name}")

with mlflow.start_run(run_name=run_name) as run:
    model_tags = {
        "model_type": "classification",
        "algorithm": "logistic_regression",
        "dataset": "iris",
        "framework": "sklearn",
        "environment": "development",
        "team": "mlops",
        "version": model_version,
        "stage": "training",
        "model_name": model_name
    }

    # Додавання тегів для категоризації
    mlflow.set_tags(model_tags)

    model_log_params = {
        "learning_rate": learning_rate,
        "epochs": epochs,
        "model_version": model_version,
        "model_name": model_name
    }
    # Логування параметрів
    mlflow.log_params(model_log_params)

    # Завантаження даних
    X, y = load_iris(return_X_y=True)
    X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=42)

    # Тренування моделі
    model = LogisticRegression(max_iter=epochs)
    model.fit(X_train, y_train)

    # Прогнозування
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)

    # Обчислення метрик
    acc = accuracy_score(y_test, y_pred)
    loss = log_loss(y_test, y_proba)

    # Логування метрик
    mlflow.log_metric("accuracy", acc)
    mlflow.log_metric("loss", loss)
    mlflow.log_metric("data", 10000)

    # Відправка метрик в Pushgateway
    push_to_prometheus(acc, loss, f"iris_training_{timestamp}")
    
    # Збереження моделі локально
    import joblib
    from datetime import datetime
    
    # Створюємо директорію для моделей
    models_dir = Path("models")
    models_dir.mkdir(exist_ok=True)
    
    # Генеруємо ім'я файлу з часовою міткою
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    model_filename = f"iris_model_{timestamp}_acc_{acc:.3f}.pkl"
    model_path = models_dir / model_filename
    
    # Зберігаємо модель локально
    joblib.dump(model, model_path)
    print(f"💾 Модель збережена локально: {model_path}")
    
    # Зберігаємо метадані моделі
    model_metadata = {
        "timestamp": timestamp,
        "algorithm": "Logistic Regression",
        "dataset": "Iris Dataset",
        "learning_rate": learning_rate,
        "epochs": epochs,
        "accuracy": acc,
        "loss": loss,
        "model_version": model_version,
        "model_name": model_name,
        "model_file": str(model_path),
        "data_shape": X_train.shape,
        "features": ["sepal_length", "sepal_width", "petal_length", "petal_width"],
        "classes": ["setosa", "versicolor", "virginica"],
        "feature_count": X_train.shape[1],
        "training_samples": X_train.shape[0],
        "test_samples": X_test.shape[0],
        "created_by": "MLOps Training Pipeline",
        "framework": "scikit-learn",
        "python_version": "3.x",
        "description": f"Iris classification model using Logistic Regression. "
                       f"Trained on {X_train.shape[0]} samples with {epochs} epochs and "
                       f"learning rate {learning_rate}. Achieved {acc:.3f} accuracy on test set.",
        "performance": {
            "accuracy": round(acc, 4),
            "loss": round(loss, 4)
        }
    }
    
    import json
    metadata_path = models_dir / f"metadata_{timestamp}.json"
    with open(metadata_path, 'w') as f:
        json.dump(model_metadata, f, indent=2)
    print(f"📄 Метадані збережені: {metadata_path}")

    # Логування моделі з підписом та прикладом вводу в MLflow
    input_example = X_test[:1]
    

    model_info = mlflow.sklearn.log_model(
        model,
        name=model_name,
        input_example=input_example,
        registered_model_name=model_name,
        metadata=model_metadata,
        tags=model_tags,
        params=model_log_params
    )

    latest_model_version = client.get_latest_versions(name=model_name, stages=["None"])[0]

    client.set_model_version_tag(
        name=model_name,
        version=latest_model_version.version,
        key="version",
        value=model_version
    )

    client.update_model_version(
        name=model_name,
        version=latest_model_version.version,
        description=model_metadata["description"]
    )

    client.update_registered_model(
        name=model_name,
        description=model_metadata["description"],
    )

    for tag in model_tags:
        client.set_registered_model_tag(
            name=model_name,
            key=tag,
            value=model_tags[tag]
        )

    # Логуємо локальний шлях як артефакт
    mlflow.log_artifact(str(model_path), "local_model")
    mlflow.log_artifact(str(metadata_path), "local_model")
    

    print(f"✅ Експеримент завершено. Модель збережена в MLflow: {model_info.model_uri}")
    print(f"💾 Локальна модель: {model_path}")
    print(f"📊 Точність: {acc:.3f}")
    # print(f"🔍 Registered Model version: {model_info.version}")