#!/usr/bin/env python3
"""
MLflow FastAPI Model Server
==========================

FastAPI application that fetches models from MLflow and serves predictions
with comprehensive logging of client requests and model operations.
"""

import os
import logging
import json
import uuid
from datetime import datetime
from typing import Dict, List, Optional, Any
from contextlib import asynccontextmanager

import mlflow
import mlflow.pyfunc
import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException, Request, BackgroundTasks
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import uvicorn

# ============================================================================
# LOGGING CONFIGURATION
# ============================================================================

# Configure detailed logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        # logging.FileHandler('/tmp/fastapi_mlflow.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

# Specialized loggers for different operations
model_logger = logging.getLogger('model_operations')
request_logger = logging.getLogger('client_requests')
performance_logger = logging.getLogger('performance')

# ============================================================================
# GLOBAL VARIABLES
# ============================================================================

# Global model storage
LOADED_MODEL = None
MODEL_INFO = {}
MODEL_STATUS = {
    "status": "not_loaded",
    "model_name": None,
    "model_version": None,
    "loaded_at": None,
    "error": None
}

# ============================================================================
# PYDANTIC MODELS
# ============================================================================

class PredictionRequest(BaseModel):
    """Request model for predictions"""
    features: List[List[float]] = Field(
        ..., 
        description="Input features for prediction (2D array)",
        example=[[5.1, 3.5, 1.4, 0.2], [6.2, 3.4, 5.4, 2.3]]
    )
    request_id: Optional[str] = Field(
        default=None,
        description="Optional request ID for tracking"
    )

class PredictionResponse(BaseModel):
    """Response model for predictions"""
    predictions: List[Any]
    request_id: str
    model_name: str
    model_version: str
    timestamp: str
    processing_time_ms: float

class ModelStatus(BaseModel):
    """Model status information"""
    status: str
    model_name: Optional[str]
    model_version: Optional[str]
    loaded_at: Optional[str]
    error: Optional[str]

class HealthResponse(BaseModel):
    """Health check response"""
    status: str
    timestamp: str
    model_ready: bool
    uptime_seconds: float

# ============================================================================
# MODEL MANAGEMENT FUNCTIONS
# ============================================================================

async def load_model_from_mlflow(
    model_name: str = "iris_classifier_demo",
    model_version: Optional[str] = None,
    model_stage: Optional[str] = None
) -> Dict[str, Any]:
    """
    Load model from MLflow with comprehensive logging
    
    Args:
        model_name: Name of the registered model
        model_version: Specific version (if None, gets latest)
        model_stage: Model stage (Production, Staging, etc.)
    
    Returns:
        Dictionary with model loading results
    """
    global LOADED_MODEL, MODEL_INFO, MODEL_STATUS
    
    operation_id = str(uuid.uuid4())[:8]
    start_time = datetime.now()
    
    model_logger.info(f"[{operation_id}] Starting model loading process")
    model_logger.info(f"[{operation_id}] Model: {model_name}, Version: {model_version}, Stage: {model_stage}")
    
    try:
        # Update status to loading
        MODEL_STATUS.update({
            "status": "loading",
            "model_name": model_name,
            "error": None
        })
        
        # Initialize MLflow client
        client = mlflow.tracking.MlflowClient()
        model_logger.info(f"[{operation_id}] MLflow client initialized")
        
        # Get model version info
        if model_version:
            model_logger.info(f"[{operation_id}] Loading specific version: {model_version}")
            model_uri = f"models:/{model_name}/{model_version}"
            mv = client.get_model_version(model_name, model_version)
        elif model_stage:
            model_logger.info(f"[{operation_id}] Loading from stage: {model_stage}")
            latest_versions = client.get_latest_versions(model_name, stages=[model_stage])
            if not latest_versions:
                raise ValueError(f"No model found in stage '{model_stage}'")
            mv = latest_versions[0]
            model_uri = f"models:/{model_name}/{model_stage}"
        else:
            model_logger.info(f"[{operation_id}] Loading latest version")
            latest_versions = client.get_latest_versions(model_name)
            if not latest_versions:
                raise ValueError(f"No versions found for model '{model_name}'")
            mv = latest_versions[0]
            model_uri = f"models:/{model_name}/{mv.version}"
        
        model_logger.info(f"[{operation_id}] Model URI: {model_uri}")
        model_logger.info(f"[{operation_id}] Model version: {mv.version}")
        
        # Load the model
        model_logger.info(f"[{operation_id}] Loading model into memory...")
        model = mlflow.pyfunc.load_model(model_uri)

        # Get comprehensive model metadata
        run = client.get_run(mv.run_id)
        
        model_info = {
            "name": model_name,
            "version": mv.version,
            "stage": mv.current_stage,
            "description": mv.description,
            "creation_timestamp": mv.creation_timestamp,
            "last_updated_timestamp": mv.last_updated_timestamp,
            "run_id": mv.run_id,
            "model_uri": model_uri,
            "user_id": mv.user_id,
            "source": mv.source,
            "status": mv.status,
            "status_message": mv.status_message,
            
            # Run information
            "run_info": {
                "experiment_id": run.info.experiment_id,
                "user_id": run.info.user_id,
                "status": run.info.status,
                "start_time": run.info.start_time,
                "end_time": run.info.end_time,
                "artifact_uri": run.info.artifact_uri,
                "lifecycle_stage": run.info.lifecycle_stage
            },
            
            # Model parameters
            "parameters": dict(run.data.params) if run.data.params else {},
            
            # Model metrics
            "metrics": dict(run.data.metrics) if run.data.metrics else {},
            
            # Model tags
            "tags": dict(run.data.tags) if run.data.tags else {},
            
            # Model signature and input/output schema
            "model_signature": None,
            "input_example": None,
            
            # Additional metadata
            "metadata": {
                "loaded_at": datetime.now().isoformat(),
                "loading_time_seconds": None,
                "model_size_mb": None,
                "framework": run.data.tags.get("mlflow.source.type", "unknown"),
                "python_version": run.data.tags.get("mlflow.source.git.commit", "unknown"),
                "mlflow_version": run.data.tags.get("mlflow.version", "unknown")
            }
        }
        
        # Try to get model signature and input example
        try:
            model_details = client.get_model_version_download_uri(model_name, mv.version)
            model_logger.info(f"[{operation_id}] Model download URI: {model_details}")
        except Exception as e:
            model_logger.warning(f"[{operation_id}] Could not get model download details: {e}")
        
        # Try to get model signature from the loaded model
        try:
            if hasattr(model, 'metadata') and model.metadata:
                if hasattr(model.metadata, 'signature'):
                    model_info["model_signature"] = str(model.metadata.signature)
                if hasattr(model.metadata, 'saved_input_example_info'):
                    model_info["input_example"] = "Available"
        except Exception as e:
            model_logger.warning(f"[{operation_id}] Could not extract model signature: {e}")
        
        # Update global variables
        LOADED_MODEL = model
        MODEL_INFO = model_info
        
        loading_time = (datetime.now() - start_time).total_seconds()
        
        # Update loading time in metadata
        model_info["metadata"]["loading_time_seconds"] = loading_time
        
        MODEL_STATUS.update({
            "status": "loaded",
            "model_name": model_name,
            "model_version": mv.version,
            "loaded_at": datetime.now().isoformat(),
            "error": None
        })
        
        model_logger.info(f"[{operation_id}] ✅ Model loaded successfully in {loading_time:.2f}s")
        model_logger.info(f"[{operation_id}] Model details: {json.dumps(model_info, indent=2)}")
        
        return {
            "success": True,
            "model_info": model_info,
            "loading_time_seconds": loading_time,
            "operation_id": operation_id
        }
        
    except Exception as e:
        loading_time = (datetime.now() - start_time).total_seconds()
        error_msg = f"Failed to load model: {str(e)}"
        
        MODEL_STATUS.update({
            "status": "error",
            "error": error_msg
        })
        
        model_logger.error(f"[{operation_id}] ❌ {error_msg}")
        model_logger.error(f"[{operation_id}] Loading failed after {loading_time:.2f}s")
        
        return {
            "success": False,
            "error": error_msg,
            "loading_time_seconds": loading_time,
            "operation_id": operation_id
        }

# ============================================================================
# APPLICATION LIFECYCLE
# ============================================================================

app_start_time = datetime.now()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan management"""
    # Startup
    logger.info("🚀 Starting FastAPI MLflow Model Server")
    
    # Try to load default model
    model_name = os.getenv("DEFAULT_MODEL_NAME", "iris_classifier_demo")
    model_version = os.getenv("DEFAULT_MODEL_VERSION")
    
    if model_name:
        logger.info(f"Loading default model: {model_name}")
        result = await load_model_from_mlflow(model_name, model_version)
        if result["success"]:
            logger.info("✅ Default model loaded successfully")
        else:
            logger.warning("⚠️ Failed to load default model, will load on demand")
    
    yield
    
    # Shutdown
    logger.info("🛑 Shutting down FastAPI MLflow Model Server")

# ============================================================================
# FASTAPI APPLICATION
# ============================================================================

app = FastAPI(
    title="MLflow Model Server",
    description="FastAPI application for serving MLflow models with comprehensive logging",
    version="1.0.0",
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============================================================================
# MIDDLEWARE FOR REQUEST LOGGING
# ============================================================================

@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Log all incoming requests"""
    request_id = str(uuid.uuid4())[:8]
    start_time = datetime.now()
    
    # Log request details
    request_logger.info(f"[{request_id}] {request.method} {request.url}")
    request_logger.info(f"[{request_id}] Client: {request.client.host if request.client else 'unknown'}")
    request_logger.info(f"[{request_id}] User-Agent: {request.headers.get('user-agent', 'unknown')}")
    
    # Process request
    response = await call_next(request)
    
    # Log response details
    processing_time = (datetime.now() - start_time).total_seconds() * 1000
    request_logger.info(f"[{request_id}] Response: {response.status_code} in {processing_time:.2f}ms")
    
    # Add request ID to response headers
    response.headers["X-Request-ID"] = request_id
    
    return response

# ============================================================================
# API ENDPOINTS
# ============================================================================

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    uptime = (datetime.now() - app_start_time).total_seconds()
    
    return HealthResponse(
        status="healthy",
        timestamp=datetime.now().isoformat(),
        model_ready=LOADED_MODEL is not None,
        uptime_seconds=uptime
    )

@app.get("/model/status", response_model=ModelStatus)
async def get_model_status():
    """Get current model status"""
    return ModelStatus(**MODEL_STATUS)

@app.get("/model/info")
async def get_model_info():
    """Get detailed model information"""
    if not LOADED_MODEL:
        raise HTTPException(status_code=404, detail="No model loaded")
    
    return {
        "model_info": MODEL_INFO,
        "status": MODEL_STATUS
    }

@app.get("/model/metadata")
async def get_comprehensive_model_metadata():
    """Get comprehensive model metadata including all MLflow details"""
    if not LOADED_MODEL:
        raise HTTPException(status_code=404, detail="No model loaded")
    
    # Add runtime information
    enhanced_metadata = MODEL_INFO.copy()
    
    # Add model introspection
    try:
        import sys
        import psutil
        import os
        
        # Get current process info
        process = psutil.Process(os.getpid())
        
        enhanced_metadata["runtime_info"] = {
            "python_version": sys.version,
            "platform": sys.platform,
            "memory_usage_mb": process.memory_info().rss / 1024 / 1024,
            "cpu_percent": process.cpu_percent(),
            "process_id": os.getpid(),
            "current_time": datetime.now().isoformat()
        }
        
        # Try to get model size information
        if hasattr(LOADED_MODEL, '_model_impl'):
            enhanced_metadata["model_details"] = {
                "model_type": str(type(LOADED_MODEL._model_impl)),
                "model_class": LOADED_MODEL._model_impl.__class__.__name__ if hasattr(LOADED_MODEL, '_model_impl') else "unknown"
            }
        
        # Get model artifacts information
        if MODEL_INFO.get("run_info", {}).get("artifact_uri"):
            enhanced_metadata["artifacts_info"] = {
                "artifact_uri": MODEL_INFO["run_info"]["artifact_uri"],
                "model_path": f"{MODEL_INFO['run_info']['artifact_uri']}/model"
            }
            
    except ImportError:
        enhanced_metadata["runtime_info"] = {
            "note": "psutil not available for detailed runtime info"
        }
    except Exception as e:
        enhanced_metadata["runtime_info"] = {
            "error": f"Could not get runtime info: {str(e)}"
        }
    
    # Add model capabilities
    enhanced_metadata["capabilities"] = {
        "can_predict": LOADED_MODEL is not None,
        "predict_method_available": hasattr(LOADED_MODEL, 'predict') if LOADED_MODEL else False,
        "predict_proba_available": hasattr(LOADED_MODEL, 'predict_proba') if LOADED_MODEL else False,
        "transform_available": hasattr(LOADED_MODEL, 'transform') if LOADED_MODEL else False
    }
    
    # Add experiment information if available
    try:
        if MODEL_INFO.get("run_info", {}).get("experiment_id"):
            client = mlflow.tracking.MlflowClient()
            experiment = client.get_experiment(MODEL_INFO["run_info"]["experiment_id"])
            enhanced_metadata["experiment_info"] = {
                "experiment_id": experiment.experiment_id,
                "name": experiment.name,
                "artifact_location": experiment.artifact_location,
                "lifecycle_stage": experiment.lifecycle_stage,
                "creation_time": experiment.creation_time,
                "last_update_time": experiment.last_update_time
            }
    except Exception as e:
        enhanced_metadata["experiment_info"] = {
            "error": f"Could not get experiment info: {str(e)}"
        }
    
    return enhanced_metadata

@app.get("/model/parameters")
async def get_model_parameters():
    """Get model training parameters"""
    if not LOADED_MODEL:
        raise HTTPException(status_code=404, detail="No model loaded")
    
    return {
        "parameters": MODEL_INFO.get("parameters", {}),
        "count": len(MODEL_INFO.get("parameters", {})),
        "model_name": MODEL_INFO.get("name"),
        "model_version": MODEL_INFO.get("version")
    }

@app.get("/model/metrics")
async def get_model_metrics():
    """Get model training metrics"""
    if not LOADED_MODEL:
        raise HTTPException(status_code=404, detail="No model loaded")
    
    return {
        "metrics": MODEL_INFO.get("metrics", {}),
        "count": len(MODEL_INFO.get("metrics", {})),
        "model_name": MODEL_INFO.get("name"),
        "model_version": MODEL_INFO.get("version")
    }

@app.get("/model/tags")
async def get_model_tags():
    """Get model tags"""
    if not LOADED_MODEL:
        raise HTTPException(status_code=404, detail="No model loaded")
    
    return {
        "tags": MODEL_INFO.get("tags", {}),
        "count": len(MODEL_INFO.get("tags", {})),
        "model_name": MODEL_INFO.get("name"),
        "model_version": MODEL_INFO.get("version")
    }

@app.get("/model/signature")
async def get_model_signature():
    """Get model signature and input/output schema"""
    if not LOADED_MODEL:
        raise HTTPException(status_code=404, detail="No model loaded")
    
    signature_info = {
        "model_signature": MODEL_INFO.get("model_signature"),
        "input_example_available": MODEL_INFO.get("input_example") is not None,
        "model_name": MODEL_INFO.get("name"),
        "model_version": MODEL_INFO.get("version")
    }
    
    # Try to get more detailed signature information
    try:
        if hasattr(LOADED_MODEL, 'metadata') and LOADED_MODEL.metadata:
            if hasattr(LOADED_MODEL.metadata, 'signature') and LOADED_MODEL.metadata.signature:
                sig = LOADED_MODEL.metadata.signature
                signature_info["detailed_signature"] = {
                    "inputs": str(sig.inputs) if sig.inputs else None,
                    "outputs": str(sig.outputs) if sig.outputs else None
                }
    except Exception as e:
        signature_info["signature_error"] = str(e)
    
    return signature_info

@app.post("/model/load")
async def load_model(
    background_tasks: BackgroundTasks,
    model_name: str = "iris_classifier_demo",
    model_version: Optional[str] = None,
    model_stage: Optional[str] = None
):
    """Load a model from MLflow"""
    logger.info(f"Received model load request: {model_name}, version: {model_version}, stage: {model_stage}")
    
    # Load model in background to avoid blocking
    result = await load_model_from_mlflow(model_name, model_version, model_stage)
    
    return {
        "message": "Model loading completed",
        "result": result
    }

@app.post("/predict", response_model=PredictionResponse)
async def predict(request: PredictionRequest):
    """Make predictions using the loaded model"""
    request_id = request.request_id or str(uuid.uuid4())[:8]
    start_time = datetime.now()
    
    request_logger.info(f"[{request_id}] Prediction request received")
    request_logger.info(f"[{request_id}] Input shape: {len(request.features)} samples")
    
    # Check if model is loaded
    if not LOADED_MODEL:
        request_logger.error(f"[{request_id}] No model loaded")
        raise HTTPException(status_code=503, detail="No model loaded. Please load a model first.")
    
    try:
        # Convert input to DataFrame (MLflow pyfunc expects pandas DataFrame)
        input_df = pd.DataFrame(request.features)
        request_logger.info(f"[{request_id}] Input converted to DataFrame: {input_df.shape}")
        
        # Make prediction
        prediction_start = datetime.now()
        predictions = LOADED_MODEL.predict(input_df)
        prediction_time = (datetime.now() - prediction_start).total_seconds() * 1000
        
        # Convert numpy arrays to lists for JSON serialization
        if isinstance(predictions, np.ndarray):
            predictions = predictions.tolist()
        
        processing_time = (datetime.now() - start_time).total_seconds() * 1000
        
        request_logger.info(f"[{request_id}] ✅ Prediction completed in {processing_time:.2f}ms")
        request_logger.info(f"[{request_id}] Model inference time: {prediction_time:.2f}ms")
        
        # Log performance metrics
        performance_logger.info(f"Prediction - Samples: {len(request.features)}, "
                              f"Total time: {processing_time:.2f}ms, "
                              f"Inference time: {prediction_time:.2f}ms")
        
        return PredictionResponse(
            predictions=predictions,
            request_id=request_id,
            model_name=MODEL_INFO.get("name", "unknown"),
            model_version=MODEL_INFO.get("version", "unknown"),
            timestamp=datetime.now().isoformat(),
            processing_time_ms=processing_time
        )
        
    except Exception as e:
        processing_time = (datetime.now() - start_time).total_seconds() * 1000
        error_msg = f"Prediction failed: {str(e)}"
        
        request_logger.error(f"[{request_id}] ❌ {error_msg}")
        request_logger.error(f"[{request_id}] Failed after {processing_time:.2f}ms")
        
        raise HTTPException(status_code=500, detail=error_msg)

@app.get("/metrics")
async def get_metrics():
    """Get application metrics"""
    uptime = (datetime.now() - app_start_time).total_seconds()
    
    return {
        "uptime_seconds": uptime,
        "model_status": MODEL_STATUS,
        "model_info": MODEL_INFO if LOADED_MODEL else None,
        "timestamp": datetime.now().isoformat()
    }

# ============================================================================
# MAIN ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    # Configuration
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", 8000))
    
    logger.info(f"Starting server on {host}:{port}")
    
    uvicorn.run(
        "app:app",
        host=host,
        port=port,
        reload=True,
        log_level="info"
    )
