# MLflow FastAPI Model Server

A comprehensive FastAPI application that fetches models from MLflow and serves them via REST API with detailed logging of client requests and model operations.

## Features

### 🚀 **Core Functionality**
- **MLflow Integration**: Automatic model fetching from MLflow registry
- **RESTful API**: Clean endpoints for predictions and model management
- **Comprehensive Logging**: Detailed logging of all operations and requests
- **Status Monitoring**: Real-time model status and health checks
- **Background Loading**: Non-blocking model loading operations

### 📊 **Logging System**
- **Request Logging**: Every client request with unique IDs and timing
- **Model Operations**: Detailed logging of model loading/fetching operations
- **Performance Metrics**: Response times and throughput monitoring
- **Error Tracking**: Comprehensive error logging and status reporting

### 🛡️ **Robust Features**
- **Error Handling**: Graceful error handling with detailed error messages
- **Input Validation**: Pydantic models for request/response validation
- **CORS Support**: Cross-origin resource sharing enabled
- **Health Checks**: Application and model health monitoring
- **Metrics Endpoint**: Application performance and status metrics

## Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Set Environment Variables (Optional)

```bash
export DEFAULT_MODEL_NAME="iris_classifier_demo"
export DEFAULT_MODEL_VERSION="1"
export MLFLOW_TRACKING_URI="http://localhost:5000"
export HOST="0.0.0.0"
export PORT="8000"
```

### 3. Start the Server

```bash
python app.py
```

The server will start on `http://localhost:8000`

### 4. Test with the Client

```bash
python client_example.py
```

## API Endpoints

### 🏥 **Health & Status**

- **GET** `/health` - Health check
- **GET** `/model/status` - Current model status
- **GET** `/model/info` - Detailed model information
- **GET** `/metrics` - Application metrics

### 🤖 **Model Management**

- **POST** `/model/load` - Load model from MLflow
  - Parameters: `model_name`, `model_version` (optional), `model_stage` (optional)

### 🔮 **Predictions**

- **POST** `/predict` - Make predictions
  - Body: `{"features": [[...]], "request_id": "optional"}`

## Example Usage

### Loading a Model

```bash
curl -X POST "http://localhost:8000/model/load?model_name=iris_classifier_demo&model_version=1"
```

### Making Predictions

```bash
curl -X POST "http://localhost:8000/predict" \
  -H "Content-Type: application/json" \
  -d '{
    "features": [[5.1, 3.5, 1.4, 0.2], [6.2, 3.4, 5.4, 2.3]],
    "request_id": "my-test-request"
  }'
```

### Checking Status

```bash
curl "http://localhost:8000/model/status"
```

## Logging

The application creates comprehensive logs in multiple categories:

### 📝 **Log Files**
- `/tmp/fastapi_mlflow.log` - Main application log

### 🏷️ **Log Categories**
- **General**: Overall application operations
- **Model Operations**: Model loading, fetching, status changes
- **Client Requests**: All incoming requests with timing and details
- **Performance**: Response times and throughput metrics

### 📊 **Log Format**
```
2024-01-15 10:30:45 - model_operations - INFO - [abc12345] Model loaded successfully in 2.34s
2024-01-15 10:30:46 - client_requests - INFO - [def67890] POST /predict
2024-01-15 10:30:46 - client_requests - INFO - [def67890] Response: 200 in 45.67ms
```

## Model Status States

- **`not_loaded`** - No model currently loaded
- **`loading`** - Model is being loaded from MLflow
- **`loaded`** - Model successfully loaded and ready for predictions
- **`error`** - Error occurred during model loading

## Response Format

### Prediction Response
```json
{
  "predictions": [0, 2, 1],
  "request_id": "abc123",
  "model_name": "iris_classifier_demo",
  "model_version": "1",
  "timestamp": "2024-01-15T10:30:46.123456",
  "processing_time_ms": 45.67
}
```

### Model Status Response
```json
{
  "status": "loaded",
  "model_name": "iris_classifier_demo",
  "model_version": "1",
  "loaded_at": "2024-01-15T10:30:45.123456",
  "error": null
}
```

## Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DEFAULT_MODEL_NAME` | `iris_classifier_demo` | Model to load on startup |
| `DEFAULT_MODEL_VERSION` | `None` | Specific version (uses latest if not set) |
| `MLFLOW_TRACKING_URI` | MLflow default | MLflow tracking server URL |
| `HOST` | `0.0.0.0` | Server host |
| `PORT` | `8000` | Server port |

## Error Handling

The application provides detailed error responses:

- **503 Service Unavailable**: No model loaded
- **500 Internal Server Error**: Prediction or model loading errors
- **422 Unprocessable Entity**: Invalid input format
- **404 Not Found**: Model not found in MLflow

## Performance Features

- **Request ID Tracking**: Every request gets a unique ID for tracing
- **Response Time Logging**: All requests logged with processing time
- **Background Operations**: Model loading doesn't block the API
- **Efficient Serialization**: Optimized JSON responses
- **Memory Management**: Proper model lifecycle management

## Monitoring

Use the `/metrics` endpoint to monitor:
- Application uptime
- Model status and information
- Current timestamp
- Model loading statistics

## Development

### Running in Development Mode

```bash
uvicorn app:app --reload --host 0.0.0.0 --port 8000
```

### Testing

Use the provided `client_example.py` for comprehensive testing:

```bash
python client_example.py
```

This will test:
- Health checks
- Model loading
- Various prediction scenarios
- Performance testing
- Error handling

## Production Deployment

For production deployment, consider:

1. **Environment Variables**: Set all required environment variables
2. **Log Management**: Configure log rotation and centralized logging
3. **Security**: Add authentication/authorization if needed
4. **Monitoring**: Integrate with monitoring systems
5. **Scaling**: Use multiple workers with Gunicorn/uWSGI

```bash
gunicorn app:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

## Troubleshooting

### Common Issues

1. **Model Not Loading**: Check MLflow connection and model name/version
2. **Prediction Errors**: Verify input format matches model expectations
3. **Connection Issues**: Ensure MLflow server is accessible
4. **Permission Errors**: Check file permissions for log files

### Debug Mode

Set logging level to DEBUG for detailed information:

```python
logging.basicConfig(level=logging.DEBUG)
```
