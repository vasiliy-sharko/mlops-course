#!/usr/bin/env python3
"""
FastAPI MLflow Model Server Client Example
==========================================

Example client to test the FastAPI MLflow model server
with various scenarios and comprehensive logging.
"""

import requests
import json
import time
from typing import List, Dict, Any


class MLflowModelClient:
    """Client for interacting with the MLflow model server"""
    
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        
    def health_check(self) -> Dict[str, Any]:
        """Check server health"""
        print("🔍 Checking server health...")
        try:
            response = self.session.get(f"{self.base_url}/health")
            response.raise_for_status()
            result = response.json()
            print(f"✅ Server is healthy: {result}")
            return result
        except Exception as e:
            print(f"❌ Health check failed: {e}")
            return {"error": str(e)}
    
    def get_model_status(self) -> Dict[str, Any]:
        """Get current model status"""
        print("📊 Getting model status...")
        try:
            response = self.session.get(f"{self.base_url}/model/status")
            response.raise_for_status()
            result = response.json()
            print(f"📋 Model status: {result}")
            return result
        except Exception as e:
            print(f"❌ Failed to get model status: {e}")
            return {"error": str(e)}
    
    def get_model_info(self) -> Dict[str, Any]:
        """Get detailed model information"""
        print("📖 Getting model info...")
        try:
            response = self.session.get(f"{self.base_url}/model/info")
            response.raise_for_status()
            result = response.json()
            print(f"📄 Model info: {json.dumps(result, indent=2)}")
            return result
        except Exception as e:
            print(f"❌ Failed to get model info: {e}")
            return {"error": str(e)}
    
    def get_comprehensive_metadata(self) -> Dict[str, Any]:
        """Get comprehensive model metadata"""
        print("🔍 Getting comprehensive model metadata...")
        try:
            response = self.session.get(f"{self.base_url}/model/metadata")
            response.raise_for_status()
            result = response.json()
            print(f"📊 Comprehensive metadata available with {len(result)} top-level keys")
            return result
        except Exception as e:
            print(f"❌ Failed to get comprehensive metadata: {e}")
            return {"error": str(e)}
    
    def get_model_parameters(self) -> Dict[str, Any]:
        """Get model training parameters"""
        print("⚙️ Getting model parameters...")
        try:
            response = self.session.get(f"{self.base_url}/model/parameters")
            response.raise_for_status()
            result = response.json()
            print(f"📋 Parameters ({result.get('count', 0)}): {result.get('parameters', {})}")
            return result
        except Exception as e:
            print(f"❌ Failed to get model parameters: {e}")
            return {"error": str(e)}
    
    def get_model_metrics(self) -> Dict[str, Any]:
        """Get model training metrics"""
        print("📈 Getting model metrics...")
        try:
            response = self.session.get(f"{self.base_url}/model/metrics")
            response.raise_for_status()
            result = response.json()
            print(f"📊 Metrics ({result.get('count', 0)}): {result.get('metrics', {})}")
            return result
        except Exception as e:
            print(f"❌ Failed to get model metrics: {e}")
            return {"error": str(e)}
    
    def get_model_tags(self) -> Dict[str, Any]:
        """Get model tags"""
        print("🏷️ Getting model tags...")
        try:
            response = self.session.get(f"{self.base_url}/model/tags")
            response.raise_for_status()
            result = response.json()
            print(f"🏷️ Tags ({result.get('count', 0)}): {result.get('tags', {})}")
            return result
        except Exception as e:
            print(f"❌ Failed to get model tags: {e}")
            return {"error": str(e)}
    
    def get_model_signature(self) -> Dict[str, Any]:
        """Get model signature"""
        print("✍️ Getting model signature...")
        try:
            response = self.session.get(f"{self.base_url}/model/signature")
            response.raise_for_status()
            result = response.json()
            print(f"✍️ Signature info: {json.dumps(result, indent=2)}")
            return result
        except Exception as e:
            print(f"❌ Failed to get model signature: {e}")
            return {"error": str(e)}
    
    def load_model(self, model_name: str, model_version: str = None, model_stage: str = None) -> Dict[str, Any]:
        """Load a model from MLflow"""
        print(f"📥 Loading model: {model_name}")
        if model_version:
            print(f"   Version: {model_version}")
        if model_stage:
            print(f"   Stage: {model_stage}")
            
        try:
            params = {"model_name": model_name}
            if model_version:
                params["model_version"] = model_version
            if model_stage:
                params["model_stage"] = model_stage
                
            response = self.session.post(f"{self.base_url}/model/load", params=params)
            response.raise_for_status()
            result = response.json()
            print(f"✅ Model loading result: {result}")
            return result
        except Exception as e:
            print(f"❌ Failed to load model: {e}")
            return {"error": str(e)}
    
    def predict(self, features: List[List[float]], request_id: str = None) -> Dict[str, Any]:
        """Make predictions"""
        print(f"🔮 Making prediction for {len(features)} samples...")
        if request_id:
            print(f"   Request ID: {request_id}")
            
        try:
            payload = {"features": features}
            if request_id:
                payload["request_id"] = request_id
                
            response = self.session.post(f"{self.base_url}/predict", json=payload)
            response.raise_for_status()
            result = response.json()
            print(f"✅ Prediction successful:")
            print(f"   Predictions: {result['predictions']}")
            print(f"   Processing time: {result['processing_time_ms']:.2f}ms")
            print(f"   Request ID: {result['request_id']}")
            return result
        except Exception as e:
            print(f"❌ Prediction failed: {e}")
            return {"error": str(e)}
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get application metrics"""
        print("📈 Getting application metrics...")
        try:
            response = self.session.get(f"{self.base_url}/metrics")
            response.raise_for_status()
            result = response.json()
            print(f"📊 Metrics: {json.dumps(result, indent=2)}")
            return result
        except Exception as e:
            print(f"❌ Failed to get metrics: {e}")
            return {"error": str(e)}


def run_comprehensive_test():
    """Run comprehensive test scenarios"""
    print("🚀 Starting MLflow Model Server Client Test")
    print("=" * 50)
    
    # Initialize client
    client = MLflowModelClient()
    
    # 1. Health check
    print("\n1️⃣ HEALTH CHECK")
    print("-" * 20)
    health = client.health_check()
    
    # 2. Check initial model status
    print("\n2️⃣ INITIAL MODEL STATUS")
    print("-" * 25)
    status = client.get_model_status()
    
    # 3. Load model if not loaded
    if status.get("status") != "loaded":
        print("\n3️⃣ LOADING MODEL")
        print("-" * 18)
        load_result = client.load_model("iris_classifier_demo")
        
        # Wait a bit for loading to complete
        print("⏳ Waiting for model to load...")
        time.sleep(2)
        
        # Check status again
        status = client.get_model_status()
    
    # 4. Get model info
    print("\n4️⃣ MODEL INFORMATION")
    print("-" * 20)
    info = client.get_model_info()
    
    # 4a. Get comprehensive metadata
    print("\n📊 COMPREHENSIVE METADATA")
    print("-" * 25)
    comprehensive_metadata = client.get_comprehensive_metadata()
    
    # 4b. Get model parameters
    print("\n⚙️ MODEL PARAMETERS")
    print("-" * 18)
    parameters = client.get_model_parameters()
    
    # 4c. Get model metrics
    print("\n📈 MODEL METRICS")
    print("-" * 15)
    metrics = client.get_model_metrics()
    
    # 4d. Get model tags
    print("\n🏷️ MODEL TAGS")
    print("-" * 12)
    tags = client.get_model_tags()
    
    # 4e. Get model signature
    print("\n✍️ MODEL SIGNATURE")
    print("-" * 17)
    signature = client.get_model_signature()
    
    # 5. Test predictions
    print("\n5️⃣ PREDICTION TESTS")
    print("-" * 19)
    
    # Test case 1: Single prediction
    print("\n🧪 Test 1: Single sample prediction")
    single_sample = [[5.1, 3.5, 1.4, 0.2]]  # Iris setosa
    result1 = client.predict(single_sample, "test-single")
    
    # Test case 2: Multiple predictions
    print("\n🧪 Test 2: Multiple samples prediction")
    multiple_samples = [
        [5.1, 3.5, 1.4, 0.2],  # Iris setosa
        [6.2, 3.4, 5.4, 2.3],  # Iris virginica
        [5.8, 2.7, 4.1, 1.0]   # Iris versicolor
    ]
    result2 = client.predict(multiple_samples, "test-multiple")
    
    # Test case 3: Large batch
    print("\n🧪 Test 3: Large batch prediction")
    large_batch = [[5.0 + i*0.1, 3.0 + i*0.05, 1.0 + i*0.2, 0.1 + i*0.1] for i in range(100)]
    result3 = client.predict(large_batch, "test-large-batch")
    
    # 6. Performance test
    print("\n6️⃣ PERFORMANCE TEST")
    print("-" * 18)
    
    # Multiple rapid requests
    print("🏃 Testing rapid requests...")
    times = []
    for i in range(10):
        start_time = time.time()
        client.predict([[5.1, 3.5, 1.4, 0.2]], f"perf-test-{i}")
        end_time = time.time()
        times.append((end_time - start_time) * 1000)
    
    print(f"⚡ Average response time: {sum(times)/len(times):.2f}ms")
    print(f"🔥 Min response time: {min(times):.2f}ms")
    print(f"🐌 Max response time: {max(times):.2f}ms")
    
    # 7. Get final metrics
    print("\n7️⃣ FINAL METRICS")
    print("-" * 16)
    app_metrics = client.get_metrics()
    
    print("\n📋 METADATA SUMMARY")
    print("-" * 17)
    if comprehensive_metadata and "error" not in comprehensive_metadata:
        print(f"✅ Model loaded: {comprehensive_metadata.get('name', 'unknown')} v{comprehensive_metadata.get('version', 'unknown')}")
        print(f"📊 Parameters: {len(comprehensive_metadata.get('parameters', {}))}")
        print(f"📈 Metrics: {len(comprehensive_metadata.get('metrics', {}))}")
        print(f"🏷️ Tags: {len(comprehensive_metadata.get('tags', {}))}")
        if comprehensive_metadata.get('runtime_info'):
            print(f"💾 Memory usage: {comprehensive_metadata['runtime_info'].get('memory_usage_mb', 'unknown'):.1f}MB")
        if comprehensive_metadata.get('experiment_info'):
            print(f"🧪 Experiment: {comprehensive_metadata['experiment_info'].get('name', 'unknown')}")
    else:
        print("⚠️ Comprehensive metadata not available")
    
    print("\n✅ Test completed successfully!")
    print("🔍 Check the server logs for detailed request tracking")


def test_error_scenarios():
    """Test error handling scenarios"""
    print("\n🚨 TESTING ERROR SCENARIOS")
    print("=" * 30)
    
    client = MLflowModelClient()
    
    # Test 1: Invalid input format
    print("\n❌ Test 1: Invalid input format")
    try:
        response = requests.post(
            "http://localhost:8000/predict",
            json={"features": "invalid"}  # String instead of list
        )
        print(f"Response: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"Error: {e}")
    
    # Test 2: Missing features
    print("\n❌ Test 2: Missing features")
    try:
        response = requests.post(
            "http://localhost:8000/predict",
            json={}  # No features
        )
        print(f"Response: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"Error: {e}")
    
    # Test 3: Wrong feature dimensions
    print("\n❌ Test 3: Wrong feature dimensions")
    result = client.predict([[1, 2, 3]], "test-wrong-dims")  # Only 3 features instead of 4
    

if __name__ == "__main__":
    print("🎯 MLflow Model Server Client Test Suite")
    print("=" * 50)
    
    try:
        # Run main tests
        run_comprehensive_test()
        
        # Test error scenarios
        test_error_scenarios()
        
    except KeyboardInterrupt:
        print("\n⚠️ Test interrupted by user")
    except Exception as e:
        print(f"\n💥 Test failed with error: {e}")
    
    print("\n🏁 Test suite completed")
