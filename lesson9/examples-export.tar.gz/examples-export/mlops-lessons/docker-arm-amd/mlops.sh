#!/bin/sh
echo "This script is started with params $1 $2."