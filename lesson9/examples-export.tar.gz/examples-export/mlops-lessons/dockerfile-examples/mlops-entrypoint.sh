#!/bin/sh
echo "Hello з ENTRYPOINT!"
echo "Script arguments: $@"