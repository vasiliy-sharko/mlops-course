#!/bin/sh
echo "mlops-entrypoint-cmd.sh, $1!"