# mlflow-infra
the repository for hosting argocd application for infra part: monitoring, ci/cd etc

# will contain helm charts
